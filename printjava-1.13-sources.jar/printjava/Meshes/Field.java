package printjava.Meshes;

import java.util.function.Function;

import printjava.Mesh;
import printjava.Triangle;
import printjava.Point;

public class Field extends Mesh {
    public double width, height, depth;
    public int xDivisions, yDivisions, zDivisions;
    Function<Point, Double> f;

    private static final int MIN_DIVISIONS = 2;
    private static final int MAX_DIVISIONS = 2000;
    private static final long MAX_CUBE_COUNT = 12_000_000L;

    private int clampDivisions(int value) {
        return Math.max(MIN_DIVISIONS, Math.min(value, MAX_DIVISIONS));
    }

    private void normalizeDivisions() {
        this.xDivisions = clampDivisions(this.xDivisions);
        this.yDivisions = clampDivisions(this.yDivisions);
        this.zDivisions = clampDivisions(this.zDivisions);

        long cubeCount = (long) (this.xDivisions - 1) * (this.yDivisions - 1) * (this.zDivisions - 1);
        if (cubeCount <= MAX_CUBE_COUNT) {
            return;
        }

        double scale = Math.cbrt((double) MAX_CUBE_COUNT / cubeCount);
        this.xDivisions = Math.max(MIN_DIVISIONS, (int) (this.xDivisions * scale));
        this.yDivisions = Math.max(MIN_DIVISIONS, (int) (this.yDivisions * scale));
        this.zDivisions = Math.max(MIN_DIVISIONS, (int) (this.zDivisions * scale));

        this.xDivisions = clampDivisions(this.xDivisions);
        this.yDivisions = clampDivisions(this.yDivisions);
        this.zDivisions = clampDivisions(this.zDivisions);

        while ((long) (this.xDivisions - 1) * (this.yDivisions - 1) * (this.zDivisions - 1) > MAX_CUBE_COUNT) {
            if (this.xDivisions >= this.yDivisions && this.xDivisions >= this.zDivisions
                    && this.xDivisions > MIN_DIVISIONS) {
                this.xDivisions--;
            } else if (this.yDivisions >= this.xDivisions && this.yDivisions >= this.zDivisions
                    && this.yDivisions > MIN_DIVISIONS) {
                this.yDivisions--;
            } else if (this.zDivisions > MIN_DIVISIONS) {
                this.zDivisions--;
            } else {
                break;
            }
        }
    }

    private static class PointValue {
        public final double x, y, z;
        public final double value;

        /**
         * PointValues the specified value.
         * 
         * @param x     the x value.
         * @param y     the y value.
         * @param z     the z value.
         * @param value the value value.
         * @return the public result.
         */
        public PointValue(double x, double y, double z, double value) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.value = value;
        }

        /**
         * ToPoints the specified value.
         * 
         * @return the Point result.
         */
        public Point toPoint() {
            return new Point(x, y, z);
        }
    }

    /**
     * Constructs a Field mesh from a function with default dimensions and
     * divisions.
     * 
     * @param f The function that defines the field. It should take a Point and
     *          return a double representing the density at that point.
     */
    public Field(Function<Point, Double> f) {
        super();
        this.width = 1;
        this.height = 1;
        this.depth = 1;
        this.xDivisions = 100;
        this.yDivisions = 100;
        this.zDivisions = 100;
        this.f = f;
    }

    /**
     * Constructs a Field mesh from a function and dimensions.
     * 
     * @param f      The function that defines the field. It should take a Point and
     *               return a double representing the density at that point.
     * @param width  The width of the field in the x-axis.
     * @param height The height of the field in the y-axis.
     * @param depth  The depth of the field in the z-axis.
     */
    public Field(Function<Point, Double> f, double width, double height, double depth) {
        super();
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.xDivisions = (int) (width * 100);
        this.yDivisions = (int) (height * 100);
        this.zDivisions = (int) (depth * 100);
        this.f = f;
    }

    /**
     * Constructs a Field mesh from a function, dimensions, and divisions.
     * 
     * @param f          The function that defines the field. It should take a Point
     *                   and return a double representing the density at that point.
     * @param width      The width of the field in the x-axis.
     * @param height     The height of the field in the y-axis.
     * @param depth      The depth of the field in the z-axis.
     * @param xDivisions The number of divisions in the x-axis. This determines the
     *                   resolution of the mesh. Higher values will result in a more
     *                   detailed mesh but will take longer to generate.
     * @param yDivisions The number of divisions in the y-axis. This determines the
     *                   resolution of the mesh. Higher values will result in a more
     *                   detailed mesh but will take longer to generate.
     * @param zDivisions The number of divisions in the z-axis. This determines the
     *                   resolution of the mesh. Higher values will result in a more
     *                   detailed mesh but will take longer to generate.
     */
    public Field(Function<Point, Double> f, double width, double height, double depth, int xDivisions, int yDivisions,
            int zDivisions) {
        super();
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.xDivisions = xDivisions;
        this.yDivisions = yDivisions;
        this.zDivisions = zDivisions;
        this.f = f;
    }

    /**
     * Generates a 3D mesh from a function.
     * This function uses the marching cubes algorithm to generate the mesh.
     * For more info on the Marching Cubes Algorithm, see:
     * https://paulbourke.net/geometry/polygonise/
     * https://youtu.be/M3iI2l0ltbE?si=Xa66wd-XEU3Fn80s
     */
    public void generate() {
        this.triangles.clear();
        generateTriangles(this::add);
    }

    /**
     * Generates triangles using the marching cubes algorithm and passes them to a
     * consumer function.
     */
    public void generateTriangles(java.util.function.Consumer<Triangle> consumer) {
        normalizeDivisions();

        double dx = width / xDivisions;
        double dy = height / yDivisions;
        double dz = depth / zDivisions;
        double isolevel = 0.1;

        float[][] currentSlice = new float[xDivisions][yDivisions];
        float[][] nextSlice = new float[xDivisions][yDivisions];

        for (int i = 0; i < xDivisions; i++) {
            for (int j = 0; j < yDivisions; j++) {
                double x = i * dx - (width / 2);
                double y = j * dy - (height / 2);
                double z = 0 * dz - (depth / 2);
                currentSlice[i][j] = f.apply(new Point(x, y, z)).floatValue();
            }
        }

        if (zDivisions > 1) {
            for (int i = 0; i < xDivisions; i++) {
                for (int j = 0; j < yDivisions; j++) {
                    double x = i * dx - (width / 2);
                    double y = j * dy - (height / 2);
                    double z = 1 * dz - (depth / 2);
                    nextSlice[i][j] = f.apply(new Point(x, y, z)).floatValue();
                }
            }
        }

        for (int k = 0; k < zDivisions - 1; k++) {
            for (int i = 0; i < xDivisions - 1; i++) {
                for (int j = 0; j < yDivisions - 1; j++) {
                    PointValue[] cubeCorners = new PointValue[8];
                    for (int n = 0; n < 8; n++) {
                        int xOffset = (n & 1);
                        int yOffset = (n & 2) >> 1;
                        int zOffset = (n & 4) >> 2;

                        double x1 = (i + xOffset) * dx - (width / 2);
                        double y1 = (j + yOffset) * dy - (height / 2);
                        double z1 = (k + zOffset) * dz - (depth / 2);

                        float value = zOffset == 0 ? currentSlice[i + xOffset][j + yOffset]
                                : nextSlice[i + xOffset][j + yOffset];

                        cubeCorners[n] = new PointValue(x1, y1, z1, value);
                    }

                    int cubeIndex = 0;
                    for (int n = 0; n < 8; n++) {
                        if (cubeCorners[n].value < isolevel)
                            cubeIndex |= 1 << n;
                    }

                    if (EDGE_TABLE[cubeIndex] == 0)
                        continue;

                    Point[] vertlist = new Point[12];
                    for (int e = 0; e < 12; e++) {
                        if ((EDGE_TABLE[cubeIndex] & (1 << e)) != 0) {
                            int v1 = EDGE_VERTEX_INDICES[e][0];
                            int v2 = EDGE_VERTEX_INDICES[e][1];
                            vertlist[e] = interpolate(isolevel, cubeCorners[v1], cubeCorners[v2]);
                        }
                    }

                    for (int t = 0; TRIANGLE_TABLE[cubeIndex][t] != -1; t += 3) {
                        Point p1 = vertlist[TRIANGLE_TABLE[cubeIndex][t]];
                        Point p2 = vertlist[TRIANGLE_TABLE[cubeIndex][t + 1]];
                        Point p3 = vertlist[TRIANGLE_TABLE[cubeIndex][t + 2]];
                        if (p1 != null && p2 != null && p3 != null) {
                            consumer.accept(new Triangle(p3, p2, p1));
                        }
                    }
                }
            }

            if (!this.hideProgress && k % 5 == 0) {
                double progress = k / (double) (zDivisions - 1);
                System.out.printf("\rRendering progress: %.2f%%", progress * 100);
            }

            if (k < zDivisions - 2) {
                float[][] temp = currentSlice;
                currentSlice = nextSlice;
                nextSlice = temp;

                int nextZ = k + 2;
                for (int i = 0; i < xDivisions; i++) {
                    for (int j = 0; j < yDivisions; j++) {
                        double x = i * dx - (width / 2);
                        double y = j * dy - (height / 2);
                        double z = nextZ * dz - (depth / 2);
                        nextSlice[i][j] = f.apply(new Point(x, y, z)).floatValue();
                    }
                }
            }
        }
    }

    /**
     * Math for finding the middle point between two points.
     */
    private Point interpolate(double isolevel, PointValue p1, PointValue p2) {
        if (Math.abs(isolevel - p1.value) < 0.00001)
            return new Point(p1.x, p1.y, p1.z);
        if (Math.abs(isolevel - p2.value) < 0.00001)
            return new Point(p2.x, p2.y, p2.z);
        if (Math.abs(p1.value - p2.value) < 0.00001)
            return new Point(p1.x, p1.y, p1.z);

        double mu = (isolevel - p1.value) / (p2.value - p1.value);
        return new Point(
                p1.x + mu * (p2.x - p1.x),
                p1.y + mu * (p2.y - p1.y),
                p1.z + mu * (p2.z - p1.z));
    }

    /**
     * The following tables are precalculated values for the marching cubes
     * algorithm.
     * https://gist.github.com/dwilliamson/c041e3454a713e58baf6e4f8e5fffecd
     */
    private static final int[][] TRIANGLE_TABLE = {
            { -1 },
            { 0, 3, 8, -1 },
            { 0, 9, 1, -1 },
            { 3, 8, 1, 1, 8, 9, -1 },
            { 2, 11, 3, -1 },
            { 8, 0, 11, 11, 0, 2, -1 },
            { 3, 2, 11, 1, 0, 9, -1 },
            { 11, 1, 2, 11, 9, 1, 11, 8, 9, -1 },
            { 1, 10, 2, -1 },
            { 0, 3, 8, 2, 1, 10, -1 },
            { 10, 2, 9, 9, 2, 0, -1 },
            { 8, 2, 3, 8, 10, 2, 8, 9, 10, -1 },
            { 11, 3, 10, 10, 3, 1, -1 },
            { 10, 0, 1, 10, 8, 0, 10, 11, 8, -1 },
            { 9, 3, 0, 9, 11, 3, 9, 10, 11, -1 },
            { 8, 9, 11, 11, 9, 10, -1 },
            { 4, 8, 7, -1 },
            { 7, 4, 3, 3, 4, 0, -1 },
            { 4, 8, 7, 0, 9, 1, -1 },
            { 1, 4, 9, 1, 7, 4, 1, 3, 7, -1 },
            { 8, 7, 4, 11, 3, 2, -1 },
            { 4, 11, 7, 4, 2, 11, 4, 0, 2, -1 },
            { 0, 9, 1, 8, 7, 4, 11, 3, 2, -1 },
            { 7, 4, 11, 11, 4, 2, 2, 4, 9, 2, 9, 1, -1 },
            { 4, 8, 7, 2, 1, 10, -1 },
            { 7, 4, 3, 3, 4, 0, 10, 2, 1, -1 },
            { 10, 2, 9, 9, 2, 0, 7, 4, 8, -1 },
            { 10, 2, 3, 10, 3, 4, 3, 7, 4, 9, 10, 4, -1 },
            { 1, 10, 3, 3, 10, 11, 4, 8, 7, -1 },
            { 10, 11, 1, 11, 7, 4, 1, 11, 4, 1, 4, 0, -1 },
            { 7, 4, 8, 9, 3, 0, 9, 11, 3, 9, 10, 11, -1 },
            { 7, 4, 11, 4, 9, 11, 9, 10, 11, -1 },
            { 9, 4, 5, -1 },
            { 9, 4, 5, 8, 0, 3, -1 },
            { 4, 5, 0, 0, 5, 1, -1 },
            { 5, 8, 4, 5, 3, 8, 5, 1, 3, -1 },
            { 9, 4, 5, 11, 3, 2, -1 },
            { 2, 11, 0, 0, 11, 8, 5, 9, 4, -1 },
            { 4, 5, 0, 0, 5, 1, 11, 3, 2, -1 },
            { 5, 1, 4, 1, 2, 11, 4, 1, 11, 4, 11, 8, -1 },
            { 1, 10, 2, 5, 9, 4, -1 },
            { 9, 4, 5, 0, 3, 8, 2, 1, 10, -1 },
            { 2, 5, 10, 2, 4, 5, 2, 0, 4, -1 },
            { 10, 2, 5, 5, 2, 4, 4, 2, 3, 4, 3, 8, -1 },
            { 11, 3, 10, 10, 3, 1, 4, 5, 9, -1 },
            { 4, 5, 9, 10, 0, 1, 10, 8, 0, 10, 11, 8, -1 },
            { 11, 3, 0, 11, 0, 5, 0, 4, 5, 10, 11, 5, -1 },
            { 4, 5, 8, 5, 10, 8, 10, 11, 8, -1 },
            { 8, 7, 9, 9, 7, 5, -1 },
            { 3, 9, 0, 3, 5, 9, 3, 7, 5, -1 },
            { 7, 0, 8, 7, 1, 0, 7, 5, 1, -1 },
            { 7, 5, 3, 3, 5, 1, -1 },
            { 5, 9, 7, 7, 9, 8, 2, 11, 3, -1 },
            { 2, 11, 7, 2, 7, 9, 7, 5, 9, 0, 2, 9, -1 },
            { 2, 11, 3, 7, 0, 8, 7, 1, 0, 7, 5, 1, -1 },
            { 2, 11, 1, 11, 7, 1, 7, 5, 1, -1 },
            { 8, 7, 9, 9, 7, 5, 2, 1, 10, -1 },
            { 10, 2, 1, 3, 9, 0, 3, 5, 9, 3, 7, 5, -1 },
            { 7, 5, 8, 5, 10, 2, 8, 5, 2, 8, 2, 0, -1 },
            { 10, 2, 5, 2, 3, 5, 3, 7, 5, -1 },
            { 8, 7, 5, 8, 5, 9, 11, 3, 10, 3, 1, 10, -1 },
            { 5, 11, 7, 10, 11, 5, 1, 9, 0, -1 },
            { 11, 5, 10, 7, 5, 11, 8, 3, 0, -1 },
            { 5, 11, 7, 10, 11, 5, -1 },
            { 6, 7, 11, -1 },
            { 7, 11, 6, 3, 8, 0, -1 },
            { 6, 7, 11, 0, 9, 1, -1 },
            { 9, 1, 8, 8, 1, 3, 6, 7, 11, -1 },
            { 3, 2, 7, 7, 2, 6, -1 },
            { 0, 7, 8, 0, 6, 7, 0, 2, 6, -1 },
            { 6, 7, 2, 2, 7, 3, 9, 1, 0, -1 },
            { 6, 7, 8, 6, 8, 1, 8, 9, 1, 2, 6, 1, -1 },
            { 11, 6, 7, 10, 2, 1, -1 },
            { 3, 8, 0, 11, 6, 7, 10, 2, 1, -1 },
            { 0, 9, 2, 2, 9, 10, 7, 11, 6, -1 },
            { 6, 7, 11, 8, 2, 3, 8, 10, 2, 8, 9, 10, -1 },
            { 7, 10, 6, 7, 1, 10, 7, 3, 1, -1 },
            { 8, 0, 7, 7, 0, 6, 6, 0, 1, 6, 1, 10, -1 },
            { 7, 3, 6, 3, 0, 9, 6, 3, 9, 6, 9, 10, -1 },
            { 6, 7, 10, 7, 8, 10, 8, 9, 10, -1 },
            { 11, 6, 8, 8, 6, 4, -1 },
            { 6, 3, 11, 6, 0, 3, 6, 4, 0, -1 },
            { 11, 6, 8, 8, 6, 4, 1, 0, 9, -1 },
            { 1, 3, 9, 3, 11, 6, 9, 3, 6, 9, 6, 4, -1 },
            { 2, 8, 3, 2, 4, 8, 2, 6, 4, -1 },
            { 4, 0, 6, 6, 0, 2, -1 },
            { 9, 1, 0, 2, 8, 3, 2, 4, 8, 2, 6, 4, -1 },
            { 9, 1, 4, 1, 2, 4, 2, 6, 4, -1 },
            { 4, 8, 6, 6, 8, 11, 1, 10, 2, -1 },
            { 1, 10, 2, 6, 3, 11, 6, 0, 3, 6, 4, 0, -1 },
            { 11, 6, 4, 11, 4, 8, 10, 2, 9, 2, 0, 9, -1 },
            { 10, 4, 9, 6, 4, 10, 11, 2, 3, -1 },
            { 4, 8, 3, 4, 3, 10, 3, 1, 10, 6, 4, 10, -1 },
            { 1, 10, 0, 10, 6, 0, 6, 4, 0, -1 },
            { 4, 10, 6, 9, 10, 4, 0, 8, 3, -1 },
            { 4, 10, 6, 9, 10, 4, -1 },
            { 6, 7, 11, 4, 5, 9, -1 },
            { 4, 5, 9, 7, 11, 6, 3, 8, 0, -1 },
            { 1, 0, 5, 5, 0, 4, 11, 6, 7, -1 },
            { 11, 6, 7, 5, 8, 4, 5, 3, 8, 5, 1, 3, -1 },
            { 3, 2, 7, 7, 2, 6, 9, 4, 5, -1 },
            { 5, 9, 4, 0, 7, 8, 0, 6, 7, 0, 2, 6, -1 },
            { 3, 2, 6, 3, 6, 7, 1, 0, 5, 0, 4, 5, -1 },
            { 6, 1, 2, 5, 1, 6, 4, 7, 8, -1 },
            { 10, 2, 1, 6, 7, 11, 4, 5, 9, -1 },
            { 0, 3, 8, 4, 5, 9, 11, 6, 7, 10, 2, 1, -1 },
            { 7, 11, 6, 2, 5, 10, 2, 4, 5, 2, 0, 4, -1 },
            { 8, 4, 7, 5, 10, 6, 3, 11, 2, -1 },
            { 9, 4, 5, 7, 10, 6, 7, 1, 10, 7, 3, 1, -1 },
            { 10, 6, 5, 7, 8, 4, 1, 9, 0, -1 },
            { 4, 3, 0, 7, 3, 4, 6, 5, 10, -1 },
            { 10, 6, 5, 8, 4, 7, -1 },
            { 9, 6, 5, 9, 11, 6, 9, 8, 11, -1 },
            { 11, 6, 3, 3, 6, 0, 0, 6, 5, 0, 5, 9, -1 },
            { 11, 6, 5, 11, 5, 0, 5, 1, 0, 8, 11, 0, -1 },
            { 11, 6, 3, 6, 5, 3, 5, 1, 3, -1 },
            { 9, 8, 5, 8, 3, 2, 5, 8, 2, 5, 2, 6, -1 },
            { 5, 9, 6, 9, 0, 6, 0, 2, 6, -1 },
            { 1, 6, 5, 2, 6, 1, 3, 0, 8, -1 },
            { 1, 6, 5, 2, 6, 1, -1 },
            { 2, 1, 10, 9, 6, 5, 9, 11, 6, 9, 8, 11, -1 },
            { 9, 0, 1, 3, 11, 2, 5, 10, 6, -1 },
            { 11, 0, 8, 2, 0, 11, 10, 6, 5, -1 },
            { 3, 11, 2, 5, 10, 6, -1 },
            { 1, 8, 3, 9, 8, 1, 5, 10, 6, -1 },
            { 6, 5, 10, 0, 1, 9, -1 },
            { 8, 3, 0, 5, 10, 6, -1 },
            { 6, 5, 10, -1 },
            { 10, 5, 6, -1 },
            { 0, 3, 8, 6, 10, 5, -1 },
            { 10, 5, 6, 9, 1, 0, -1 },
            { 3, 8, 1, 1, 8, 9, 6, 10, 5, -1 },
            { 2, 11, 3, 6, 10, 5, -1 },
            { 8, 0, 11, 11, 0, 2, 5, 6, 10, -1 },
            { 1, 0, 9, 2, 11, 3, 6, 10, 5, -1 },
            { 5, 6, 10, 11, 1, 2, 11, 9, 1, 11, 8, 9, -1 },
            { 5, 6, 1, 1, 6, 2, -1 },
            { 5, 6, 1, 1, 6, 2, 8, 0, 3, -1 },
            { 6, 9, 5, 6, 0, 9, 6, 2, 0, -1 },
            { 6, 2, 5, 2, 3, 8, 5, 2, 8, 5, 8, 9, -1 },
            { 3, 6, 11, 3, 5, 6, 3, 1, 5, -1 },
            { 8, 0, 1, 8, 1, 6, 1, 5, 6, 11, 8, 6, -1 },
            { 11, 3, 6, 6, 3, 5, 5, 3, 0, 5, 0, 9, -1 },
            { 5, 6, 9, 6, 11, 9, 11, 8, 9, -1 },
            { 5, 6, 10, 7, 4, 8, -1 },
            { 0, 3, 4, 4, 3, 7, 10, 5, 6, -1 },
            { 5, 6, 10, 4, 8, 7, 0, 9, 1, -1 },
            { 6, 10, 5, 1, 4, 9, 1, 7, 4, 1, 3, 7, -1 },
            { 7, 4, 8, 6, 10, 5, 2, 11, 3, -1 },
            { 10, 5, 6, 4, 11, 7, 4, 2, 11, 4, 0, 2, -1 },
            { 4, 8, 7, 6, 10, 5, 3, 2, 11, 1, 0, 9, -1 },
            { 1, 2, 10, 11, 7, 6, 9, 5, 4, -1 },
            { 2, 1, 6, 6, 1, 5, 8, 7, 4, -1 },
            { 0, 3, 7, 0, 7, 4, 2, 1, 6, 1, 5, 6, -1 },
            { 8, 7, 4, 6, 9, 5, 6, 0, 9, 6, 2, 0, -1 },
            { 7, 2, 3, 6, 2, 7, 5, 4, 9, -1 },
            { 4, 8, 7, 3, 6, 11, 3, 5, 6, 3, 1, 5, -1 },
            { 5, 0, 1, 4, 0, 5, 7, 6, 11, -1 },
            { 9, 5, 4, 6, 11, 7, 0, 8, 3, -1 },
            { 11, 7, 6, 9, 5, 4, -1 },
            { 6, 10, 4, 4, 10, 9, -1 },
            { 6, 10, 4, 4, 10, 9, 3, 8, 0, -1 },
            { 0, 10, 1, 0, 6, 10, 0, 4, 6, -1 },
            { 6, 10, 1, 6, 1, 8, 1, 3, 8, 4, 6, 8, -1 },
            { 9, 4, 10, 10, 4, 6, 3, 2, 11, -1 },
            { 2, 11, 8, 2, 8, 0, 6, 10, 4, 10, 9, 4, -1 },
            { 11, 3, 2, 0, 10, 1, 0, 6, 10, 0, 4, 6, -1 },
            { 6, 8, 4, 11, 8, 6, 2, 10, 1, -1 },
            { 4, 1, 9, 4, 2, 1, 4, 6, 2, -1 },
            { 3, 8, 0, 4, 1, 9, 4, 2, 1, 4, 6, 2, -1 },
            { 6, 2, 4, 4, 2, 0, -1 },
            { 3, 8, 2, 8, 4, 2, 4, 6, 2, -1 },
            { 4, 6, 9, 6, 11, 3, 9, 6, 3, 9, 3, 1, -1 },
            { 8, 6, 11, 4, 6, 8, 9, 0, 1, -1 },
            { 11, 3, 6, 3, 0, 6, 0, 4, 6, -1 },
            { 8, 6, 11, 4, 6, 8, -1 },
            { 10, 7, 6, 10, 8, 7, 10, 9, 8, -1 },
            { 3, 7, 0, 7, 6, 10, 0, 7, 10, 0, 10, 9, -1 },
            { 6, 10, 7, 7, 10, 8, 8, 10, 1, 8, 1, 0, -1 },
            { 6, 10, 7, 10, 1, 7, 1, 3, 7, -1 },
            { 3, 2, 11, 10, 7, 6, 10, 8, 7, 10, 9, 8, -1 },
            { 2, 9, 0, 10, 9, 2, 6, 11, 7, -1 },
            { 0, 8, 3, 7, 6, 11, 1, 2, 10, -1 },
            { 7, 6, 11, 1, 2, 10, -1 },
            { 2, 1, 9, 2, 9, 7, 9, 8, 7, 6, 2, 7, -1 },
            { 2, 7, 6, 3, 7, 2, 0, 1, 9, -1 },
            { 8, 7, 0, 7, 6, 0, 6, 2, 0, -1 },
            { 7, 2, 3, 6, 2, 7, -1 },
            { 8, 1, 9, 3, 1, 8, 11, 7, 6, -1 },
            { 11, 7, 6, 1, 9, 0, -1 },
            { 6, 11, 7, 0, 8, 3, -1 },
            { 11, 7, 6, -1 },
            { 7, 11, 5, 5, 11, 10, -1 },
            { 10, 5, 11, 11, 5, 7, 0, 3, 8, -1 },
            { 7, 11, 5, 5, 11, 10, 0, 9, 1, -1 },
            { 7, 11, 10, 7, 10, 5, 3, 8, 1, 8, 9, 1, -1 },
            { 5, 2, 10, 5, 3, 2, 5, 7, 3, -1 },
            { 5, 7, 10, 7, 8, 0, 10, 7, 0, 10, 0, 2, -1 },
            { 0, 9, 1, 5, 2, 10, 5, 3, 2, 5, 7, 3, -1 },
            { 9, 7, 8, 5, 7, 9, 10, 1, 2, -1 },
            { 1, 11, 2, 1, 7, 11, 1, 5, 7, -1 },
            { 8, 0, 3, 1, 11, 2, 1, 7, 11, 1, 5, 7, -1 },
            { 7, 11, 2, 7, 2, 9, 2, 0, 9, 5, 7, 9, -1 },
            { 7, 9, 5, 8, 9, 7, 3, 11, 2, -1 },
            { 3, 1, 7, 7, 1, 5, -1 },
            { 8, 0, 7, 0, 1, 7, 1, 5, 7, -1 },
            { 0, 9, 3, 9, 5, 3, 5, 7, 3, -1 },
            { 9, 7, 8, 5, 7, 9, -1 },
            { 8, 5, 4, 8, 10, 5, 8, 11, 10, -1 },
            { 0, 3, 11, 0, 11, 5, 11, 10, 5, 4, 0, 5, -1 },
            { 1, 0, 9, 8, 5, 4, 8, 10, 5, 8, 11, 10, -1 },
            { 10, 3, 11, 1, 3, 10, 9, 5, 4, -1 },
            { 3, 2, 8, 8, 2, 4, 4, 2, 10, 4, 10, 5, -1 },
            { 10, 5, 2, 5, 4, 2, 4, 0, 2, -1 },
            { 5, 4, 9, 8, 3, 0, 10, 1, 2, -1 },
            { 2, 10, 1, 4, 9, 5, -1 },
            { 8, 11, 4, 11, 2, 1, 4, 11, 1, 4, 1, 5, -1 },
            { 0, 5, 4, 1, 5, 0, 2, 3, 11, -1 },
            { 0, 11, 2, 8, 11, 0, 4, 9, 5, -1 },
            { 5, 4, 9, 2, 3, 11, -1 },
            { 4, 8, 5, 8, 3, 5, 3, 1, 5, -1 },
            { 0, 5, 4, 1, 5, 0, -1 },
            { 5, 4, 9, 3, 0, 8, -1 },
            { 5, 4, 9, -1 },
            { 11, 4, 7, 11, 9, 4, 11, 10, 9, -1 },
            { 0, 3, 8, 11, 4, 7, 11, 9, 4, 11, 10, 9, -1 },
            { 11, 10, 7, 10, 1, 0, 7, 10, 0, 7, 0, 4, -1 },
            { 3, 10, 1, 11, 10, 3, 7, 8, 4, -1 },
            { 3, 2, 10, 3, 10, 4, 10, 9, 4, 7, 3, 4, -1 },
            { 9, 2, 10, 0, 2, 9, 8, 4, 7, -1 },
            { 3, 4, 7, 0, 4, 3, 1, 2, 10, -1 },
            { 7, 8, 4, 10, 1, 2, -1 },
            { 7, 11, 4, 4, 11, 9, 9, 11, 2, 9, 2, 1, -1 },
            { 1, 9, 0, 4, 7, 8, 2, 3, 11, -1 },
            { 7, 11, 4, 11, 2, 4, 2, 0, 4, -1 },
            { 4, 7, 8, 2, 3, 11, -1 },
            { 9, 4, 1, 4, 7, 1, 7, 3, 1, -1 },
            { 7, 8, 4, 1, 9, 0, -1 },
            { 3, 4, 7, 0, 4, 3, -1 },
            { 7, 8, 4, -1 },
            { 11, 10, 8, 8, 10, 9, -1 },
            { 0, 3, 9, 3, 11, 9, 11, 10, 9, -1 },
            { 1, 0, 10, 0, 8, 10, 8, 11, 10, -1 },
            { 10, 3, 11, 1, 3, 10, -1 },
            { 3, 2, 8, 2, 10, 8, 10, 9, 8, -1 },
            { 9, 2, 10, 0, 2, 9, -1 },
            { 8, 3, 0, 10, 1, 2, -1 },
            { 2, 10, 1, -1 },
            { 2, 1, 11, 1, 9, 11, 9, 8, 11, -1 },
            { 11, 2, 3, 9, 0, 1, -1 },
            { 11, 0, 8, 2, 0, 11, -1 },
            { 3, 11, 2, -1 },
            { 1, 8, 3, 9, 8, 1, -1 },
            { 1, 9, 0, -1 },
            { 8, 3, 0, -1 },
            { -1 }
    };

    private static final int[] EDGE_TABLE = {
            0x0, 0x109, 0x203, 0x30a, 0x80c, 0x905, 0xa0f, 0xb06,
            0x406, 0x50f, 0x605, 0x70c, 0xc0a, 0xd03, 0xe09, 0xf00,
            0x190, 0x99, 0x393, 0x29a, 0x99c, 0x895, 0xb9f, 0xa96,
            0x596, 0x49f, 0x795, 0x69c, 0xd9a, 0xc93, 0xf99, 0xe90,
            0x230, 0x339, 0x33, 0x13a, 0xa3c, 0xb35, 0x83f, 0x936,
            0x636, 0x73f, 0x435, 0x53c, 0xe3a, 0xf33, 0xc39, 0xd30,
            0x3a0, 0x2a9, 0x1a3, 0xaa, 0xbac, 0xaa5, 0x9af, 0x8a6,
            0x7a6, 0x6af, 0x5a5, 0x4ac, 0xfaa, 0xea3, 0xda9, 0xca0,
            0x8c0, 0x9c9, 0xac3, 0xbca, 0xcc, 0x1c5, 0x2cf, 0x3c6,
            0xcc6, 0xdcf, 0xec5, 0xfcc, 0x4ca, 0x5c3, 0x6c9, 0x7c0,
            0x950, 0x859, 0xb53, 0xa5a, 0x15c, 0x55, 0x35f, 0x256,
            0xd56, 0xc5f, 0xf55, 0xe5c, 0x55a, 0x453, 0x759, 0x650,
            0xaf0, 0xbf9, 0x8f3, 0x9fa, 0x2fc, 0x3f5, 0xff, 0x1f6,
            0xef6, 0xfff, 0xcf5, 0xdfc, 0x6fa, 0x7f3, 0x4f9, 0x5f0,
            0xb60, 0xa69, 0x963, 0x86a, 0x36c, 0x265, 0x16f, 0x66,
            0xf66, 0xe6f, 0xd65, 0xc6c, 0x76a, 0x663, 0x569, 0x460,
            0x460, 0x569, 0x663, 0x76a, 0xc6c, 0xd65, 0xe6f, 0xf66,
            0x66, 0x16f, 0x265, 0x36c, 0x86a, 0x963, 0xa69, 0xb60,
            0x5f0, 0x4f9, 0x7f3, 0x6fa, 0xdfc, 0xcf5, 0xfff, 0xef6,
            0x1f6, 0xff, 0x3f5, 0x2fc, 0x9fa, 0x8f3, 0xbf9, 0xaf0,
            0x650, 0x759, 0x453, 0x55a, 0xe5c, 0xf55, 0xc5f, 0xd56,
            0x256, 0x35f, 0x55, 0x15c, 0xa5a, 0xb53, 0x859, 0x950,
            0x7c0, 0x6c9, 0x5c3, 0x4ca, 0xfcc, 0xec5, 0xdcf, 0xcc6,
            0x3c6, 0x2cf, 0x1c5, 0xcc, 0xbca, 0xac3, 0x9c9, 0x8c0,
            0xca0, 0xda9, 0xea3, 0xfaa, 0x4ac, 0x5a5, 0x6af, 0x7a6,
            0x8a6, 0x9af, 0xaa5, 0xbac, 0xaa, 0x1a3, 0x2a9, 0x3a0,
            0xd30, 0xc39, 0xf33, 0xe3a, 0x53c, 0x435, 0x73f, 0x636,
            0x936, 0x83f, 0xb35, 0xa3c, 0x13a, 0x33, 0x339, 0x230,
            0xe90, 0xf99, 0xc93, 0xd9a, 0x69c, 0x795, 0x49f, 0x596,
            0xa96, 0xb9f, 0x895, 0x99c, 0x29a, 0x393, 0x99, 0x190,
            0xf00, 0xe09, 0xd03, 0xc0a, 0x70c, 0x605, 0x50f, 0x406,
            0xb06, 0xa0f, 0x905, 0x80c, 0x30a, 0x203, 0x109, 0x0
    };

    private static final int[][] EDGE_VERTEX_INDICES = {
            { 0, 1 }, { 1, 3 }, { 3, 2 }, { 2, 0 },
            { 4, 5 }, { 5, 7 }, { 7, 6 }, { 6, 4 },
            { 0, 4 }, { 1, 5 }, { 3, 7 }, { 2, 6 }
    };
}
